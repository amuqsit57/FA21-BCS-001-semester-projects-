import mysql.connector
import random #for generation random booking number

mydb=mysql.connector.connect(host="localhost",user="root",passwd="password123",database="rentcardb")
mycursor=mydb.cursor()


def colored(r, g, b, text):
    return "\033[38;2;{};{};{}m{} \033[38;2;255;255;255m".format(r, g, b, text)
names=[]

asking=print("welcome to the 001s rent a car service","what do you want to search",colored(213,132,131,"1.book a car"),colored(0,233,433,"2.Available cars"),colored(0,233,111,"3.Details of cars"),colored(210,264,43,"4.Returning a car"),sep="\n")
 
ask=input("enter the initials of the options: ") 

def CarReturningSection(): 
    print("welcome to car retuning section")

    booking=(input("please enter the car booking number which was given to you at the time of booking: "))
    
    sql="SELECT booking_number from clients_details "
    
    mycursor.execute(sql)
    myresult3=mycursor.fetchall()
    mydb.commit()

    sql="SELECT name_of_client from clients_details where booking_number=%s"
    val=[(booking)]
    mycursor.execute(sql, val)
    myresult=mycursor.fetchall()
    mydb.commit()

    sql="SELECT car_booked from clients_details where booking_number=%s"
    val=[(booking)]
    mycursor.execute(sql,val)
    myresult1=mycursor.fetchall()
    mydb.commit()
    
    for i in myresult:
        for j in i:
            van=j
    for k in myresult1:
        for carToBeEnteredInTheDataBAse in k:
            c=0
    for h in myresult3:
        for l in h:
            book=l
    while book != booking:
        booking=(input("please enter the car booking number which was given to you at the time of booking: "))
    print("Is your name is ",van,"\n"+"enter y for yes or n for no")
    ask=input()
    
    if ask == "y":
        print("thank you! the car has been returned ")
        sql="UPDATE cars_details set status_of_car ='available' where cars=%s"
        val=[(carToBeEnteredInTheDataBAse)]
        mycursor.execute(sql, val)
        mydb.commit()
    
    
    elif ask == "n":
        print("sorry there is issue in the server")
def CarBookSection():
    
    print("welcome to book a car section") 
    name=input("enter your name: ")
    address=input("enter the address: ")
    phn=input("enter the phone number: ")
    booking=random.randint(1000000,93131313)
                                                                                                
    while len(phn)<11:    
        print(colored(255,0,0,"please enter the phone number with 11 digits")) 
        phn=input("enter the phone number: ")
    #accessing data from the database
    def select():
        mycursor.execute("SELECT id, cars, status_of_car FROM cars_details ")
        myresult =mycursor.fetchall()
        return myresult
    print("The available cars are: ")
    print("id :   car   :  status")
    l=select()
    for i in l:
        x=0
        for j in i:
            
            if x<2:
                print(j,end="  ")
            if x==2:
                print(j)
            x=x+1
    # cars to be issued

    y=(input("enter the identity number of the car: "))

    
    #accessing the data from the database
    def statusOfCar():
        sql="SELECT status_of_car FROM cars_details WHERE id=%s"
        val=[(y)]
        mycursor.execute(sql,val)
        myresult= mycursor.fetchall()
        return myresult
    l=statusOfCar()    
    for i in l:
        for j in i:
            b=0
            print(j)
    while j != "available":
        print("sorry this car is not available. please enter the car availble")
        y=(input("enter the identity number of the car: "))
        sql="SELECT status_of_car FROM cars_details WHERE id=%s"
        val=[(y)]
        mycursor.execute(sql,val)
        myresult= mycursor.fetchall()
        for i in myresult:
            for j in i:
                b=0
                print(j)
    #accessing thr data from the database
    def issue_car():
        sql="SELECT cars FROM cars_details WHERE id=%s"
        val=[(y)]
        mycursor.execute(sql, val)
        myresult= mycursor.fetchall()
    
        return myresult
    l=issue_car()
    for i in l:
        for j in i:
            print("do you want to issue this car: ",str(j))
            car_booked=j
    

    #accessing the data from the database
    def rent_car():


        sql="SELECT rent FROM cars_details where id=%s"
        val=[y]
        mycursor.execute(sql, val)
        myresult=mycursor.fetchall()
        return myresult
    l=rent_car()
    
    for i in l:
        for j in i:
            
            print("The rent of this car is: ",str(j),"$")
            rent_of_car=j
            days=eval(input("please enter the days to issue: "))
            rent=days*int(j)
            print("your total rent would be: ",rent)
             

    
    


    # asking the user that if he wants to issue the car
    ask=input("if you want to issue this car enter y otherwise n: ")

    if "y" in ask:
        print("ok your car has been confirmed \n \
 your details has been saved \n \
 Your booking number is this please note that number ",booking)

        print("please pay the due amount at the counter")
       

    
        #Changing the status of the car
        sql = "UPDATE cars_details set status_of_car='unavailable' where id=%s "
        val=[(y)]
        mycursor.execute(sql, val)
        mydb.commit 

        


        #storing in the database
        
        sqlform="Insert into clients_details(booking_number,name_of_client,address,phone,car_booked,rent_of_car,days_issued) values(%s,%s,%s,%s,%s,%s,%s)"
        clients_details=[(booking),(name),(address),(phn),(car_booked),(rent_of_car),(days)]
        mycursor.execute(sqlform,clients_details)
        mydb.commit()
    else:
        print("thank you for visiting")
def AvailableCarsSection():
    print("welcome to Available cars section")
    print("these are the available cars")
    

    #function for accessing the data from the database
    def select():
        sql="SELECT id, cars,status_of_car FROM cars_details"
        mycursor.execute(sql)
        myresult=mycursor.fetchall()
        return myresult

    #portion showning the carsz available using lists
    id = []
    l=select()
    for i in l:
        for j in i:
            id.append(j)
    i=0
    y=0
    b=1
    k=2
    while i!= len(id):
        
        x=id[y]
        y=y+3
        print(x, end=" |")
        a=id[b]
        b=b+3
        print(format(a,"20s"), end=" |")
        j=id[k]
        k=k+3
        print(j)
        i=i+3
def DetailsOfCarsSection():
    def select():
        sql="SELECT cars, driver_name, rent FROM cars_details"
        mycursor.execute(sql)
        myresult=mycursor.fetchall()
        return myresult
    details=[]
    l=select()
    for i in l:
        for j in i:
            details.append(j)
    i=0
    b=0
    y=1
    k=2
    print(format("car","30s"),format("driver","28s") ,"rent")
    while i != len(details):
        a=details[b]
        b=b+3
        print(format(a,"25s")," |",end=" ")
        x=details[y]
        y=y+3
        print(format(x,"26s")," |",end=" ")
        j=details[k]
        k=k+3
        print(j)
        i=i+3


    

 
    
if "1" in ask:
    CarBookSection()
    
if "2" in ask:
    AvailableCarsSection()
if "3" in ask:
    DetailsOfCarsSection()
if "4" in ask:
   CarReturningSection()













    


