import mysql.connector
mydb=mysql.connector.connect(host="localhost",user="root",passwd="password123",database="rentcardb")
mycursor=mydb.cursor()
cars="cars"
while cars !='q':
    id=input("enter the car identity number: ")
    cars=input("enter the car to be refistered in the database: (for exit press q): ")
    status=input("enter the status of the car: ")
    driver_name=input("enter the name of the driver: ")
    rent=input("enter the rent of the car: ")


    sqlform="Insert into cars_details(id, cars, status_of_car, driver_name, rent) values(%s, %s,%s,%s,%s)"

    cars_details=[(id),(cars),(status),(driver_name),(rent)]
    mycursor.execute(sqlform,cars_details)
    mydb.commit()