import mysql.connector
mydb=mysql.connector.connect(host="localhost",user="root",passwd="password123",database="rentcardb")
mycursor=mydb.cursor()

sql_delete_querry="DELETE FROM cars_details WHERE rent='10$'"
    
mycursor.execute(sql_delete_querry)
mydb.commit()