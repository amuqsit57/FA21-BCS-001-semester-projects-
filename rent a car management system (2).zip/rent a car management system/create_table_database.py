import mysql.connector
mydb=mysql.connector.connect(host="localhost",user="root",passwd="password123",database="rentcardb")
mycursor=mydb.cursor()
# mycursor.execute("Create table clients_details(booking_number varchar(200), name_of_client varchar(200),address varchar(200),phone varchar(200),car_booked varchar(200),rent_of_car varchar(200),days_issued varchar(200))")

# #mycursor.execute("Create table cars_details(id varchar(200) ,cars varchar(200),status_of_car varchar(200), driver_name varchar(200), rent varchar(200))")

# for updating

# sql="UPDATE cars_details set status_of_car='available' where id='1' "
# mycursor.execute(sql)
# mydb.commit()